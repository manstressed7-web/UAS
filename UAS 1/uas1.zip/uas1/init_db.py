import sqlite3

conn = sqlite3.connect("database.db")
c = conn.cursor()

c.execute("PRAGMA foreign_keys = ON")

c.execute("DROP TABLE IF EXISTS penduduk")

c.execute("""
CREATE TABLE penduduk (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT NOT NULL,
    jenis_kelamin TEXT,
    status_pernikahan TEXT,
    ayah_id INTEGER,
    ibu_id INTEGER,
    pasangan_id INTEGER,

    FOREIGN KEY (ayah_id) REFERENCES penduduk(id),
    FOREIGN KEY (ibu_id) REFERENCES penduduk(id),
    FOREIGN KEY (pasangan_id) REFERENCES penduduk(id)
)
""")

conn.commit()
conn.close()

print("Database siap.")
