import sqlite3
from faker import Faker
import random

fake = Faker("id_ID")

conn = sqlite3.connect("database.db")
c = conn.cursor()

def add(nama, jk, status, ayah=None, ibu=None, pasangan=None):

    c.execute("""
        INSERT INTO penduduk
        (nama, jenis_kelamin, status_pernikahan, ayah_id, ibu_id, pasangan_id)
        VALUES (?,?,?,?,?,?)
    """, (nama, jk, status, ayah, ibu, pasangan))

    return c.lastrowid

people = []

for i in range(1000):

    jk = random.choice(["Laki-laki", "Perempuan"])

    if jk == "Laki-laki":
        nama = fake.name_male()
    else:
        nama = fake.name_female()

    pid = add(
        nama,
        jk,
        "Belum Menikah"
    )

    people.append(pid)


conn.commit()

random.shuffle(people)

for i in range(0, len(people)-1, 2):

    p1 = people[i]
    p2 = people[i+1]

    c.execute("""
        UPDATE penduduk
        SET pasangan_id=?, status_pernikahan='Menikah'
        WHERE id=?
    """, (p2, p1))

    c.execute("""
        UPDATE penduduk
        SET pasangan_id=?, status_pernikahan='Menikah'
        WHERE id=?
    """, (p1, p2))


conn.commit()

c.execute("""
    SELECT id, pasangan_id
    FROM penduduk
    WHERE pasangan_id IS NOT NULL
""")

couples = c.fetchall()


for ayah, ibu in couples:

    if random.random() < 0.35:

        jumlah = random.randint(1, 4)

        for _ in range(jumlah):

            jk = random.choice(["Laki-laki", "Perempuan"])

            nama = fake.name()

            add(
                nama,
                jk,
                "Belum Menikah",
                ayah,
                ibu
            )


conn.commit()
conn.close()

print("1000+ data realistis dibuat.")