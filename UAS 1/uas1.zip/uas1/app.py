from flask import Flask, render_template, request
import sqlite3

app = Flask(__name__)

def db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def index():

    q = request.args.get("search", "")

    con = db()
    cur = con.cursor()

    if q:
        cur.execute("""
            SELECT id, nama FROM penduduk
            WHERE nama LIKE ?
            ORDER BY nama
        """, ('%' + q + '%',))
    else:
        cur.execute("SELECT id, nama FROM penduduk ORDER BY nama")

    data = cur.fetchall()
    con.close()

    return render_template("index.html", data=data, q=q)

@app.route("/detail/<int:id>")
def detail(id):

    con = db()
    cur = con.cursor()

    cur.execute("SELECT * FROM penduduk WHERE id=?", (id,))
    p = cur.fetchone()

    if not p:
        return "Data tidak ditemukan"

    ayah = "-"
    if p["ayah_id"]:
        cur.execute("SELECT nama FROM penduduk WHERE id=?", (p["ayah_id"],))
        r = cur.fetchone()
        if r:
            ayah = r["nama"]

    ibu = "-"
    if p["ibu_id"]:
        cur.execute("SELECT nama FROM penduduk WHERE id=?", (p["ibu_id"],))
        r = cur.fetchone()
        if r:
            ibu = r["nama"]

    pasangan = "-"
    if p["pasangan_id"]:
        cur.execute("SELECT nama FROM penduduk WHERE id=?", (p["pasangan_id"],))
        r = cur.fetchone()
        if r:
            pasangan = r["nama"]

    cur.execute("""
        SELECT nama FROM penduduk
        WHERE ayah_id=? OR ibu_id=?
        ORDER BY nama
    """, (id, id))

    anak = cur.fetchall()

    saudara = []

    if p["ayah_id"] or p["ibu_id"]:

        cur.execute("""
            SELECT nama FROM penduduk
            WHERE id != ?
            AND (ayah_id = ? OR ibu_id = ?)
            ORDER BY nama
        """, (id, p["ayah_id"], p["ibu_id"]))

        saudara = cur.fetchall()

    con.close()

    return render_template(
        "detail.html",
        p=p,
        ayah=ayah,
        ibu=ibu,
        pasangan=pasangan,
        anak=anak,
        saudara=saudara
    )

if __name__ == "__main__":
    app.run(debug=True)
