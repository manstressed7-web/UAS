import sqlite3

conn = sqlite3.connect("database.db")
c = conn.cursor()

def add(nama, jk, status, ayah=None, ibu=None, pasangan=None):
    c.execute("""
    INSERT INTO penduduk (nama, jenis_kelamin, status_pernikahan, ayah_id, ibu_id, pasangan_id)
    VALUES (?,?,?,?,?,?)
    """, (nama, jk, status, ayah, ibu, pasangan))
    return c.lastrowid

ayah1 = add("Budi Santoso", "Laki-laki", "Menikah")
ibu1  = add("Siti Aminah", "Perempuan", "Menikah", pasangan=ayah1)
c.execute("UPDATE penduduk SET pasangan_id=? WHERE id=?", (ibu1, ayah1))

ayah2 = add("Joko Pratama", "Laki-laki", "Menikah")
ibu2  = add("Rina Lestari", "Perempuan", "Menikah", pasangan=ayah2)
c.execute("UPDATE penduduk SET pasangan_id=? WHERE id=?", (ibu2, ayah2))

anak = []
anak.append(add("Andi Santoso", "Laki-laki", "Menikah", ayah1, ibu1))
anak.append(add("Rina Santoso", "Perempuan", "Belum Menikah", ayah1, ibu1))
anak.append(add("Dedi Pratama", "Laki-laki", "Menikah", ayah2, ibu2))
anak.append(add("Sari Pratama", "Perempuan", "Menikah", ayah2, ibu2))

p1 = add("Siti Rahma", "Perempuan", "Menikah", pasangan=anak[0])
c.execute("UPDATE penduduk SET pasangan_id=? WHERE id=?", (p1, anak[0]))

p2 = add("Lina Wati", "Perempuan", "Menikah", pasangan=anak[2])
c.execute("UPDATE penduduk SET pasangan_id=? WHERE id=?", (p2, anak[2]))

p3 = add("Agus Wijaya", "Laki-laki", "Menikah", pasangan=anak[3])
c.execute("UPDATE penduduk SET pasangan_id=? WHERE id=?", (p3, anak[3]))

for i in range(1, 6):
    add(f"Anak Andi {i}", "Laki-laki" if i % 2 else "Perempuan",
        "Belum Menikah", anak[0], p1)

for i in range(1, 5):
    add(f"Anak Dedi {i}", "Laki-laki" if i % 2 else "Perempuan",
        "Belum Menikah", anak[2], p2)

for i in range(1, 5):
    add(f"Anak Sari {i}", "Laki-laki" if i % 2 else "Perempuan",
        "Belum Menikah", p3, anak[3])

conn.commit()
conn.close()
print("±50 data penduduk berhasil dibuat.")
